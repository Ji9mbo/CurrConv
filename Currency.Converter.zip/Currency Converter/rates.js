document.getElementById('theme-switch').addEventListener('change', (event) => {
    document.body.classList.toggle('light-theme', event.target.checked);
});

document.getElementById('language-switch').addEventListener('click', () => {
    const currentLang = document.getElementById('language-switch').textContent;
    const newLang = currentLang === 'EN' ? 'RU' : 'EN';
    document.getElementById('language-switch').textContent = newLang;
    setLanguage(newLang.toLowerCase());
});

function setLanguage(lang) {
    const elements = document.querySelectorAll('[data-lang]');
    elements.forEach(el => {
        el.textContent = translations[lang][el.dataset.lang];
    });
}

const translations = {
    en: {
        rates: 'Currency Rates'
    },
    ru: {
        rates: 'Курсы валют'
    },
    en: {
        rates: 'Currency converter'
    },
    ru: {
        rates: 'Конвертер валют'
    }
};

// Пример добавления курсов валют
const ratesList = document.getElementById('rates-list');
const rates = [
    { currency: 'USD', rate: '75.00' },
    { currency: 'EUR', rate: '0.95' },
    { currency: 'GBP', rate: '0.79' },
    { currency: 'JPY', rate: '154.55' },
    { currency: 'AUD', rate: '1.55' },
    { currency: 'CAD', rate: '1.41' },
    { currency: 'SEK', rate: '0.89' },
    { currency: 'CNY', rate: '7.24' },
    { currency: 'SEK', rate: '10.98' },
    { currency: 'BYN', rate: '3.32' },
    { currency: 'NZD', rate: '1.71' },
    { currency: 'RUB', rate: '99.89' },
    { currency: 'INR', rate: '84.48' },
    { currency: 'BRL', rate: '5.80' },
    { currency: 'ZAR', rate: '18.21' },
    { currency: 'SGD', rate: '1.34' },
    { currency: 'HKD', rate: '7.79' },
    { currency: 'MXN', rate: '20.37' },
    { currency: 'PLN', rate: '24.10' },
    { currency: 'KRW', rate: '1395.21' }
];

rates.forEach(rate => {
    const li = document.createElement('li');
    li.textContent = `${rate.currency}: ${rate.rate}`;
    ratesList.appendChild(li);
});
