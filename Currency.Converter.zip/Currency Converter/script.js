const currencies = ["USD", "EUR", "GBP", "JPY", "AUD", "CAD", "CHF", "CNY", "SEK", "NZD", "BYN", "RUB", "INR", "BRL", "ZAR", "SGD", "HKD", "KRW", "MXN", "PLN"]; // Added more currencies including BYN
let favoriteCurrencies = JSON.parse(localStorage.getItem('favoriteCurrencies')) || [];
let currentTheme = 'dark';
let currentLanguage = 'en';

document.addEventListener('DOMContentLoaded', () => {
    const fromCurrency = document.getElementById('fromCurrency');
    const toCurrency = document.getElementById('toCurrency');
    const addFavoriteCurrency = document.getElementById('addFavoriteCurrency');
    populateCurrencySelect(fromCurrency);
    populateCurrencySelect(toCurrency);
    populateCurrencySelect(addFavoriteCurrency);
    applyLanguage();
    fadeInElements();
});

function populateCurrencySelect(selectElement) {
    selectElement.innerHTML = ''; // Clear existing options
    if (favoriteCurrencies.length > 0) {
        const optgroupFavorites = document.createElement('optgroup');
        optgroupFavorites.label = currentLanguage === 'en' ? 'Favorites' : 'Избранное';
        favoriteCurrencies.forEach(currency => {
            const option = document.createElement('option');
            option.value = currency;
            option.text = currency;
            optgroupFavorites.appendChild(option);
        });
        selectElement.appendChild(optgroupFavorites);
    }

    const optgroupAll = document.createElement('optgroup');
    optgroupAll.label = currentLanguage === 'en' ? 'All Currencies' : 'Все валюты';
    currencies.forEach(currency => {
        if (!favoriteCurrencies.includes(currency)) {
            const option = document.createElement('option');
            option.value = currency;
            option.text = currency;
            optgroupAll.appendChild(option);
        }
    });
    selectElement.appendChild(optgroupAll);
}

function addFavorite() {
    const addFavoriteCurrency = document.getElementById('addFavoriteCurrency').value;
    if (!favoriteCurrencies.includes(addFavoriteCurrency)) {
        favoriteCurrencies.push(addFavoriteCurrency);
        localStorage.setItem('favoriteCurrencies', JSON.stringify(favoriteCurrencies));
        updateCurrencySelects();
    }
}

function updateCurrencySelects() {
    const fromCurrency = document.getElementById('fromCurrency');
    const toCurrency = document.getElementById('toCurrency');
    populateCurrencySelect(fromCurrency);
    populateCurrencySelect(toCurrency);
}

async function convertCurrency() {
    const amount = document.getElementById('amount').value;
    if (amount < 0) {
        document.getElementById('result').innerText = currentLanguage === 'en' ? 'Amount cannot be negative' : 'Количество не может быть отрицательным';
        return;
    }
    const fromCurrency = document.getElementById('fromCurrency').value;
    const toCurrency = document.getElementById('toCurrency').value;
    const apiKey = 'YOUR_API_KEY'; // Replace with your API key
    const url = `https://api.exchangerate-api.com/v4/latest/${fromCurrency}`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        const rate = data.rates[toCurrency];
        const result = amount * rate;
        document.getElementById('result').innerText = `${amount} ${fromCurrency} = ${result.toFixed(2)} ${toCurrency}`;
    } catch (error) {
        document.getElementById('result').innerText = currentLanguage === 'en' ? 'Error fetching exchange rate' : 'Ошибка при получении курса обмена';
    }
}

function toggleTheme() {
    const body = document.body;
    if (currentTheme === 'dark') {
        body.classList.add('light-theme');
        currentTheme = 'light';
    } else {
        body.classList.remove('light-theme');
        currentTheme = 'dark';
    }
    updateGradient();
}

function changeLanguage() {
    const languageButton = document.getElementById('languageButton');
    currentLanguage = currentLanguage === 'en' ? 'ru' : 'en';
    languageButton.innerText = currentLanguage.toUpperCase();
    applyLanguage();
}

function applyLanguage() {
    const elements = {
        title: {
            en: 'Currency<br>Converter',
            ru: 'Конвертер<br>Валют'
        },
        amountPlaceholder: {
            en: 'Amount',
            ru: 'Количество'
        },
        addToFavorites: {
            en: 'Add to Favorites',
            ru: 'Добавить в Избранное'
        },
        convertButton: {
            en: 'Convert',
            ru: 'Конвертировать'
        },
        viewRatesButton: {
            en: 'View Current Rates',
            ru: 'Просмотреть текущие курсы'
        },
        addFavoriteButton: {
            en: 'Add to Favorites',
            ru: 'Добавить в Избранное'
        }
    };

    document.getElementById('title').innerHTML = elements.title[currentLanguage];
    document.getElementById('amount').placeholder = elements.amountPlaceholder[currentLanguage];
    document.getElementById('addToFavorites').innerText = elements.addToFavorites[currentLanguage];
    document.getElementById('convertButton').innerText = elements.convertButton[currentLanguage];
    document.getElementById('viewRatesButton').innerText = elements.viewRatesButton[currentLanguage];
    document.getElementById('addFavoriteButton').innerText = elements.addFavoriteButton[currentLanguage];

    updateCurrencySelects(); // Update currency select labels
}

function fadeInElements() {
    const elements = document.querySelectorAll('.container, .settings, .favorites, #result, .currency-title, footer');
    elements.forEach(element => {
        element.style.opacity = 0;
        element.style.transition = 'opacity 1s';
        setTimeout(() => {
            element.style.opacity = 1;
        }, 100);
    });
}

function updateGradient() {
    const body = document.body;
    if (currentTheme === 'dark') {
        body.style.background = 'linear-gradient(to bottom, black, var(--background-color))';
    } else {
        body.style.background = 'linear-gradient(to bottom, #d3d3d3, var(--background-color))';
    }
}
